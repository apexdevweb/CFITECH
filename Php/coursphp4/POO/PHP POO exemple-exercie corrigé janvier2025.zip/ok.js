const volvo = new Voiture("Mauve",200.0,2);
volvo.couleur = "Rouge";
volvo.demarrer();


